package MainGeocod;

/**
 * Created by 1234 on 4/2/2017.
 */
public class MainProcess {

    public String name;
    public String adName;
    public String initialAddress;
    public String lat;
    public String lng;
    public String region;


}
