package Geocoding;

import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

/**
 * Created by 1234 on 1/29/2017.
 */
public class Controller {
    @FXML
   // public Text actiontarget;

    public ProgressBar progressBar;

    public Text helo;

    public TextField userName_Field;


  public Controller() {
    }




    @FXML
    public void setActiontarget1(MouseEvent mouseEvent)throws Exception {

try{




        System.out.println("this is a second button");



    }catch (Exception e){}




}
}
